python consumer.py &
python consumer-average.py
