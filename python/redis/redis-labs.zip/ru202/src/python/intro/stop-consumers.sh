pkill -f consumer.py
pkill -f consumer-average.py
